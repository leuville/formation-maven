package org.formation.mabiblio.business;

import java.util.List;

import org.formation.mabiblio.business.dto.Auteur;

public interface AuteurMetier {

	public Auteur getAuteurByID(int id);
	
	public List<Auteur> getAuteurs();
	
	public void ajouter(Auteur auteur);
}
