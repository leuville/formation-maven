package org.formation.mabiblio.business.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.formation.mabiblio.business.LivreMetier;
import org.formation.mabiblio.business.dto.Auteur;
import org.formation.mabiblio.business.dto.Livre;
import org.formation.mabiblio.persist.dao.impl.LivreDAO;

public class LivreMetierImpl implements LivreMetier {

	private LivreDAO livreDAO = new LivreDAO();

	public Livre getLivreByID(int id) {
		org.formation.mabiblio.persist.dto.Livre livreDao = livreDAO.findByID(id); 
		return livreDao != null ? daoToBusiness(livreDao) : null ;
	}

	public List<Livre> getLivres() {
		List<org.formation.mabiblio.persist.dto.Livre> livresDao = livreDAO.findAll();
		return livresDao != null ? daoToBusiness(livresDao) : new ArrayList<Livre>();
	}

	public void ajouter(Livre livre) {
		livreDAO.save(businessToDao(livre));
	}
		
	public static List<Livre> daoToBusiness(List<org.formation.mabiblio.persist.dto.Livre> dao){
		List<Livre> livres = new ArrayList<>();
		for (org.formation.mabiblio.persist.dto.Livre livre : dao) {
			livres.add(daoToBusiness(livre));
		}
		return livres;	
	}
	
	public static org.formation.mabiblio.persist.dto.Livre businessToDao(Livre business){
		org.formation.mabiblio.persist.dto.Livre livre = 
				new org.formation.mabiblio.persist.dto.Livre();
		livre.setId(business.getId());
		livre.setTitre(business.getTitre());
		livre.setDatePublication(business.getDatePublication());
		Set<Auteur> auteurs = business.getAuteurs();
		Set<org.formation.mabiblio.persist.dto.Auteur> auteursDao = 
				new HashSet<org.formation.mabiblio.persist.dto.Auteur>();
		for (Auteur auteur : auteurs) {
			auteursDao.add(AuteurMetierImpl.businessToDao(auteur));
		}
		livre.setAuteurs(auteursDao);
		return livre;
	}
	
	public static Livre daoToBusiness(org.formation.mabiblio.persist.dto.Livre dao){
		Livre livre = new Livre();
		livre.setId(dao.getId());
		livre.setTitre(dao.getTitre());
		livre.setDatePublication(dao.getDatePublication());
		Set<org.formation.mabiblio.persist.dto.Auteur> auteurs = dao.getAuteurs();
		Set<Auteur> auteursBusiness = new HashSet<Auteur>();
		for (org.formation.mabiblio.persist.dto.Auteur auteur : auteurs) {
			auteursBusiness.add(AuteurMetierImpl.daoToBusiness(auteur));
		}
		livre.setAuteurs(auteursBusiness);
		return livre;
	}

}
