package org.formation.mabiblio.business;

import java.util.List;

import org.formation.mabiblio.business.dto.Livre;

public interface LivreMetier {

	public Livre getLivreByID(int id);
	
	public List<Livre> getLivres();
	
	public void ajouter(Livre livre);
}
