package org.formation.mabiblio.business.impl;

import java.util.ArrayList;
import java.util.List;

import org.formation.mabiblio.business.AuteurMetier;
import org.formation.mabiblio.business.dto.Auteur;
import org.formation.mabiblio.persist.dao.impl.AuteurDAO;

public class AuteurMetierImpl implements AuteurMetier {

	private AuteurDAO auteurDAO = new AuteurDAO();

	public Auteur getAuteurByID(int id) {
		org.formation.mabiblio.persist.dto.Auteur auteurDao = auteurDAO.findByID(id); 
		return auteurDao != null ? daoToBusiness(auteurDao) : null ;
	}

	public List<Auteur> getAuteurs() {
		List<org.formation.mabiblio.persist.dto.Auteur> auteursDao = auteurDAO.findAll();
		return auteursDao != null ? daoToBusiness(auteursDao) : new ArrayList<Auteur>();
	}

	public void ajouter(Auteur auteur) {
		auteurDAO.save(businessToDao(auteur));
	}
	
	public static List<Auteur> daoToBusiness(List<org.formation.mabiblio.persist.dto.Auteur> dao){
		List<Auteur> auteurs = new ArrayList<Auteur>();
		for (org.formation.mabiblio.persist.dto.Auteur auteur : dao) {
			auteurs.add(daoToBusiness(auteur));
		}
		return auteurs;	
	}
	
	public static List<org.formation.mabiblio.persist.dto.Auteur> businessToDao(List<Auteur> business){
		List<org.formation.mabiblio.persist.dto.Auteur> auteurs = 
				new ArrayList<org.formation.mabiblio.persist.dto.Auteur>();
		for (Auteur auteur : business) {
			auteurs.add(businessToDao(auteur));
		}
		return auteurs;	
	}
	
	public static org.formation.mabiblio.persist.dto.Auteur businessToDao(Auteur business){
		org.formation.mabiblio.persist.dto.Auteur auteur = 
				new org.formation.mabiblio.persist.dto.Auteur();
		auteur.setId(business.getId());
		auteur.setNom(business.getNom());
		auteur.setPrenom(business.getPrenom());
		return auteur;
	}
	
	public static Auteur daoToBusiness(org.formation.mabiblio.persist.dto.Auteur dao){
		Auteur auteur = new Auteur();
		auteur.setId(dao.getId());
		auteur.setNom(dao.getNom());
		auteur.setPrenom(dao.getPrenom());
		return auteur;
	}

}
