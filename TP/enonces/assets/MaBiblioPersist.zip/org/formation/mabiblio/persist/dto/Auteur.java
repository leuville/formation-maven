package org.formation.mabiblio.persist.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="auteur")
public class Auteur {

	@Override
	public String toString() {
		return "Auteur [id=" + id + ", prenom=" + prenom + ", nom=" + nom + "]";
	}

	@Id
	@GeneratedValue
	@Column(name="id_auteur")
	private Integer id;
	
	private String prenom;
	
	private String nom;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
	
}
