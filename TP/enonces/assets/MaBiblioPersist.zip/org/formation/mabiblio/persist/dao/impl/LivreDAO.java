package org.formation.mabiblio.persist.dao.impl;

import org.formation.mabiblio.persist.dto.Livre;

public class LivreDAO extends GenericDAOImpl<Livre, Integer> {

}
