package org.formation.mabiblio.persist.dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

/**
 * 
 * @author Cyril Dumont
 *
 * @param <T>
 * @param <ID>
 */
public interface GenericDAO<T, ID extends Serializable> {
 
    public T save(T entity);
 
    public void merge(T entity);
 
    public void delete(T entity);
 
    public List<T> findMany(Query query);
 
    public T findOne(Query query);
 
    public List<T> findAll();
 
    public T findByID(ID id);
}