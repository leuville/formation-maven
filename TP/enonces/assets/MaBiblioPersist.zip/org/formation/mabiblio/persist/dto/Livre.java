package org.formation.mabiblio.persist.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="livre")
public class Livre implements Serializable{

	@Override
	public String toString() {
		return "Livre [id=" + id + ", titre=" + titre + ", cote=" + cote
				+ ", auteurs=" + auteurs + "]";
	}

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="id_livre")
	private Integer id;
	
	
	private String titre;
	
	private String cote;
	
	@Column(name="date_publication")
	private Date datePublication; 
	
	@OneToMany
	@JoinTable(	name = "livre_auteur",
				joinColumns = @JoinColumn( name="id_livre"),
                inverseJoinColumns = @JoinColumn( name="id_auteur"))
	private Set<Auteur> auteurs;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitre() {
		
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public String getCote() {
		return cote;
	}

	public void setCote(String cote) {
		this.cote = cote;
	}

	public Set<Auteur> getAuteurs() {
		return auteurs;
	}

	public void setAuteurs(Set<Auteur> auteurs) {
		this.auteurs = auteurs;
	}

	public Date getDatePublication() {
		return datePublication;
	}

	public void setDatePublication(Date datePublication) {
		this.datePublication = datePublication;
	}
	
	
	
}
