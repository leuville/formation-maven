package org.formation.mabiblio.persist.dao.impl;

import org.formation.mabiblio.persist.dto.Auteur;


public class AuteurDAO extends GenericDAOImpl<Auteur, Integer> {

}
