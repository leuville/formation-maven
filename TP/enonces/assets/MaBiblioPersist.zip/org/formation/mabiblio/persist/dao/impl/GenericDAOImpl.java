package org.formation.mabiblio.persist.dao.impl;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.formation.mabiblio.persist.dao.GenericDAO;


public abstract class GenericDAOImpl<T, ID extends Serializable> implements
		GenericDAO<T, ID> {

	private Class<T> classType;
	
	private EntityManager em;
	
	public GenericDAOImpl() {
		classType = (Class<T>)((ParameterizedType)getClass().
				getGenericSuperclass()).getActualTypeArguments()[0];	
		EntityManagerFactory factory = 
				Persistence.createEntityManagerFactory("mabiblio-pu");
		em = factory.createEntityManager();
	}
	
	public T save(T entity) {
		em.getTransaction().begin();
		em.persist(entity);
		em.getTransaction().commit();
		return entity;
	}

	public void merge(T entity) {
		em.getTransaction().begin();
		em.merge(entity);
		em.getTransaction().commit();
	}

	public void delete(T entity) {
		em.getTransaction().begin();
		em.remove(entity);
		em.getTransaction().commit();
	}

	public List<T> findMany(Query query) {
		List<T> t;
		t = (List<T>) query.getResultList();
		return t;
	}

	public T findOne(Query query) {
		T t;
		t = (T) query.getSingleResult();
		return t;
	}

	public T findByID(ID id) {
		return em.find(classType, id);
	}

	public List<T> findAll() {
		Query query = em.createQuery("from " + classType.getName());
		return query.getResultList();
	}
}
