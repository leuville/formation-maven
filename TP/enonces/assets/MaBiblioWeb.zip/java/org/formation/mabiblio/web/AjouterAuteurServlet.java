package org.formation.mabiblio.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.formation.mabiblio.business.AuteurMetier;
import org.formation.mabiblio.business.dto.Auteur;
import org.formation.mabiblio.business.impl.AuteurMetierImpl;

public class AjouterAuteurServlet extends HttpServlet {

	private AuteurMetier auteurMetier = new AuteurMetierImpl();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nom = request.getParameter("nom");
		String prenom = request.getParameter("prenom");
		// Sauvegarde de l'auteur
		Auteur auteur = new Auteur(prenom, nom);
		auteurMetier.ajouter(auteur);
		response.sendRedirect("./listerAuteurs");
	}

}
