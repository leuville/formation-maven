package org.formation.mabiblio.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.formation.mabiblio.business.AuteurMetier;
import org.formation.mabiblio.business.dto.Auteur;
import org.formation.mabiblio.business.impl.AuteurMetierImpl;

public class ListerAuteursServlet extends HttpServlet {

	private AuteurMetier auteurMetier = new AuteurMetierImpl();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Auteur> auteurs = auteurMetier.getAuteurs();
		// Sauvegarde de la liste des livres dans la session
		request.getSession().setAttribute("auteurs", auteurs);
		RequestDispatcher dispatch = request.getRequestDispatcher("listeAuteurs.jsp");
		dispatch.forward(request, response);
	}

}
