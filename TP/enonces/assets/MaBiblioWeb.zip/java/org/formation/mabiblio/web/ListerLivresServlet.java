package org.formation.mabiblio.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.formation.mabiblio.business.LivreMetier;
import org.formation.mabiblio.business.dto.Livre;
import org.formation.mabiblio.business.impl.LivreMetierImpl;

public class ListerLivresServlet extends HttpServlet {

	private LivreMetier livreMetier = new LivreMetierImpl();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Livre> livres = livreMetier.getLivres();
		// Sauvegarde de la liste des livres dans la session
		request.getSession().setAttribute("livres", livres);
		RequestDispatcher dispatch = request.getRequestDispatcher("listeLivres.jsp");
		dispatch.forward(request, response);
	}

}
